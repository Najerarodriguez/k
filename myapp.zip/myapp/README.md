Crear el proyecto
npx create-react-app PYBOT

Instalar SASS
yarn add node-sass


npm install react-router-dom