import React from 'react';
import '../containers/login.scss';

const login = () => {
	return(
			<body className='body'> LOGIN </body>
		)
}

export default login;